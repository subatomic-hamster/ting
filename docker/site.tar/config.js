window.TING_CONFIG = { useMocks: true, ocrAssetBase: "/ocr" };
